package cat.esteve.exercicis;

public class exercici76 {
    // Realitzar un algoritme que donada una taula de N elements, canviï cada element parell per
    // l’element senar anterior. Si la taula té un nombre imparell d’elements l’últim no es canvia amb
    // ningú,finalment mostrar per pantalla la taula modificada.

    public static void main(String[] args) {

    }
}
